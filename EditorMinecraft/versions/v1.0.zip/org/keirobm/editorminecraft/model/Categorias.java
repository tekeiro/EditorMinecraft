package org.keirobm.editorminecraft.model;

/**
 * Categorias de los Bloques
 * @author Angel
 *
 */
public enum Categorias {
	TERRENO,
	MINERALES,
	CONSTRUCCION,
	INGENIERIA,
	JARDINERIA,
        GANADERIA,
        MUEBLES,
}
